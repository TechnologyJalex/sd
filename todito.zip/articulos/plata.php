<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

$usuarioActual = $_SESSION['usuario'];

// Load user data from JSON file
$usuarios = json_decode(file_get_contents('data/usuarios.json'), true);

// Filter referidos for the current user
$referidos = array_filter($usuarios, function ($usuario) use ($usuarioActual) {
    return $usuario['codigo_referido'] === $usuarioActual;
});

// Load product data from JSON file
$productos = json_decode(file_get_contents('data/articulos.json'), true);

?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Árbol Binario de Referidos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Estilos adicionales -->
    <style>
        /* Your styles remain unchanged */
    </style>
</head>
<body class="bg-dark">
    <div class="sidebar">
        <!-- Sidebar content remains unchanged -->
    </div> 

    <!-- Main Content -->
    <div class="main-content">
        <h1>Árbol Binario de Referidos</h1>

        <?php if (!empty($usuariosConArticulos[$usuarioActual]['articulos'])) : ?>
            <h3 class="mt-4">Artículos de <?php echo htmlspecialchars($usuarioActual); ?>:</h3>

            <div class="referral-list">
                <?php foreach ($usuariosConArticulos[$usuarioActual]['articulos'] as $articulo) : ?>
                    <div class="referral-list-item">
                        <h4><?php echo $articulo['nombre']; ?></h4>
                        <p><?php echo $articulo['subtitulo']; ?></p>
                        <p>Precio: $<?php echo $articulo['precio']; ?></p>
                        <!-- Add more information as needed -->
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else : ?>
            <p>No hay artículos para mostrar.</p>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS and additional scripts (if necessary) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Additional scripts can go here -->
</body>
</html>

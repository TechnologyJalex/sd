<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Detalles de Usuario</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Estilos adicionales */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 20px;
        }

        h1, h2 {
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Detalles del Usuario</h1>

        <?php
        // Leer archivo JSON de usuarios
        $json_data = file_get_contents('images.json');
        $data = json_decode($json_data, true);

        // Obtener user_id de la URL
        $selectedUserID = isset($_GET['user_id']) ? $_GET['user_id'] : null;

        // Encontrar y mostrar los detalles del usuario seleccionado
        if (!is_null($selectedUserID)) {
            $selectedUser = null;
            foreach ($data['users'] as $user) {
                if ($user['user_id'] == $selectedUserID) {
                    $selectedUser = $user;
                    break;
                }
            }

            if ($selectedUser) {
                echo "<h2>{$selectedUser['username']}</h2>";
                echo "<p><strong>User ID:</strong> {$selectedUser['user_id']}</p>";
                echo "<p><strong>Username:</strong> {$selectedUser['username']}</p>";
                echo "<p><strong>Email:</strong> {$selectedUser['email']}</p>";
            } else {
                echo "<p>No se encontraron detalles para este usuario.</p>";
            }
        } else {
            echo "<p>No se proporcionó un ID de usuario válido.</p>";
        }
        ?>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

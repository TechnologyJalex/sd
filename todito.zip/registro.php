<?php
// Obtener el código de invitación de la URL
$codigoInvitacion = $_GET['codigo_invitacion'] ?? '';

// Obtener el valor de 'referral' de la URL
$codigoReferido = $_GET['referral'] ?? '';

// Mostrar el código de invitación en el formulario
if (!empty($codigoInvitacion)) {
    echo '<div class="alert alert-info" role="alert">';
    echo '<p class="mb-0">Código de invitación: <strong>' . htmlspecialchars($codigoInvitacion) . '</strong></p>';
    echo '</div>';
}

// Mostrar el valor de 'codigo_referido' (solo para verificar)
if (!empty($codigoReferido)) {
    echo "El valor de \$codigoReferido es: " . htmlspecialchars($codigoReferido);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate form inputs
    $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_STRING);
    $apellido = filter_input(INPUT_POST, 'apellido', FILTER_SANITIZE_STRING);
    $edad = filter_input(INPUT_POST, 'edad', FILTER_VALIDATE_INT);
    $telefono = filter_input(INPUT_POST, 'telefono', FILTER_SANITIZE_STRING);
    $usuario = filter_input(INPUT_POST, 'usuario', FILTER_SANITIZE_STRING);
    $contrasena = filter_input(INPUT_POST, 'contrasena', FILTER_SANITIZE_STRING);
    $codigoReferido = filter_input(INPUT_POST, 'codigo_referido', FILTER_SANITIZE_STRING);

    // Validate edad as an integer
    if ($edad === false || $edad === null) {
        echo '<div class="alert alert-danger" role="alert">Edad debe ser un número entero válido.</div>';
    } else {
        // Read existing users data
        $usuarios = file_get_contents('data/usuarios.json');
        $usuarios = json_decode($usuarios, true);

        // Create a new user
        $nuevoUsuario = array(
            "nombre" => $nombre,
            "apellido" => $apellido,
            "edad" => $edad,
            "telefono" => $telefono,
            "usuario" => $usuario,
            "contrasena" => $contrasena,
            "codigo_referido" => $codigoReferido
        );

        // Add the new user to the array
        $usuarios[] = $nuevoUsuario;

        // Save the updated users data to the file
        file_put_contents('data/usuarios.json', json_encode($usuarios, JSON_PRETTY_PRINT));

        echo '<div class="alert alert-success" role="alert">¡Registro exitoso!</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
      /* styles.css */

body {
    color: #fff;
    background-color: #282c34;
}

.container {
    margin-top: 20px;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

input[type="text"],
input[type="password"],
input[type="number"] {
    width: 100%;
    padding: 8px;
    box-sizing: border-box;
    margin-bottom: 10px;
}

input[type="submit"] {
    background-color: #dc3545;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #c82333;
}

.alert {
    margin-top: 20px;
}

/* Optional: Style for referral code display */
.referral-code {
    background-color: #61dafb;
    color: #282c34;
    padding: 10px;
    border-radius: 4px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}

/* Optional: Style for the navigation bar */
.navbar {
    background-color: #343a40;
}

.navbar-brand {
    color: #fff;
}

.navbar-brand img {
    max-width: 40px;
    margin-right: 10px;
}

.navbar-nav a {
    color: #fff !important;
}

/* Optional: Style for the support button */
.navbar-nav .nav-link {
    display: flex;
    align-items: center;
}

.navbar-nav .nav-link i {
    margin-right: 5px;
}

    </style>
</head>
<body class="bg-dark">
    <!-- Bootstrap Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <!-- Logo -->
            <a class="navbar-brand" href="#">
                <img src="path/to/your/logo.png" alt="World Global" class="navbar-logo">
            </a>
            <a class="navbar-brand" href="#">World Global</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <!-- Support Button with Font Awesome Icon -->
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-question-circle"></i> Soporte
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2 class="text-center mb-4">Registrarse</h2>

        <form id="registroForm" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" class="form-control" required>
            
            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" class="form-control" required>
            
            <label for="edad">Edad:</label>
            <input type="number" id="edad" name="edad" class="form-control" required>
            
            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" class="form-control" required>
            
            <label for="usuario">Usuario:</label>
            <input type="text" id="usuario" name="usuario" class="form-control" required>
            
            <label for="contrasena">Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena" class="form-control" required>
            
            <?php
            // Mostrar el valor de 'referral' en el formulario si está presente en la URL
            if (!empty($codigoReferido)) {
                echo "<div class='mb-3 row'>";
                echo "<label for='referralCode' class='col-sm-2 col-form-label'>Código de Referido</label>";
                echo "<div class='col-sm-10'>";
                echo "<input type='text' class='form-control' id='referralCode' name='codigo_referido' value='$codigoReferido' readonly>";
                echo "</div></div>";
            }
            ?>
            
            <input type="submit" value="Registrarse" class="btn btn-danger mt-3">
        </form>
        
        <p class="mt-3">¿Ya tienes una cuenta? <a href="index.php">Iniciar sesión</a></p>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

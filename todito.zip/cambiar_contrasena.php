<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cambio de Contraseña</title>
</head>
<body>
    <h1>Cambio de Contraseña</h1>
    <form method="post">
        <label for="username">Nombre de Usuario:</label>
        <input type="text" name="username" id="username" placeholder="Ingresa el nombre de usuario"><br><br>
        
        <label for="newPassword">Nueva Contraseña:</label>
        <input type="password" name="newPassword" id="newPassword" placeholder="Ingresa la nueva contraseña"><br><br>
        
        <input type="submit" name="submit" value="Cambiar Contraseña">
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['usuario<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrarse</title>
</head>
<body>
    <h2>Registrarse</h2>
    
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nombre = $_POST['nombre'] ?? '';
        $apellido = $_POST['apellido'] ?? '';
        $edad = $_POST['edad'] ?? '';
        $telefono = $_POST['telefono'] ?? '';
        $usuario = $_POST['usuario'] ?? '';
        $contrasena = $_POST['contrasena'] ?? '';
        $codigoReferido = $_POST['codigo_referido'] ?? '';

        $usuarios = file_get_contents('usuarios.json');
        $usuarios = json_decode($usuarios, true);

        $nuevoUsuario = array(
            "nombre" => $nombre,
            "apellido" => $apellido,
            "edad" => $edad,
            "telefono" => $telefono,
            "usuario" => $usuario,
            "contrasena" => $contrasena,
            "codigo_referido" => $codigoReferido
        );

        $usuarios[] = $nuevoUsuario;

        file_put_contents('usuarios.json', json_encode($usuarios, JSON_PRETTY_PRINT));

        echo '<p>¡Registro exitoso!</p>';
    }
    ?>
    
    <form id="registroForm" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br><br>
        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" required>
        <br><br>
        <label for="edad">Edad:</label>
        <input type="number" id="edad" name="edad" required>
        <br><br>
        <label for="telefono">Teléfono:</label>
        <input type="text" id="telefono" name="telefono" required>
        <br><br>
        <label for="usuario">Usuario:</label>
        <input type="text" id="usuario" name="usuario" required>
        <br><br>
        <label for="contrasena">Contraseña:</label>
        <input type="password" id="contrasena" name="contrasena" required>
        <br><br>
        <label for="codigo_referido">Código de referencia:</label>
        <input type="text" id="codigo_referido" name="codigo_referido">
        <br><br>
        <input type="submit" value="Registrarse">
    </form>
    
    <p>¿Ya tienes una cuenta? <a href="index.php">Iniciar sesión</a></p>
</body>
</html>
']) && isset($_POST['newPassword'])) {
            $username = $_POST['usuario'];
            $newPassword = $_POST['newPassword'];

            // Leer el archivo users.json
            $jsonFile = 'usuarios.json';
            $jsonData = file_get_contents($jsonFile);
            $usersData = json_decode($jsonData, true);

            // Buscar el usuario y actualizar la contraseña si se encuentra
            $userIndex = -1;
            foreach ($usersData['usuario'] as $index => $user) {
                if ($user['usuario'] === $username) {
                    $userIndex = $index;
                    break;
                }
            }

            if ($userIndex !== -1) {
                $usersData['usuario'][$userIndex]['contrasena'] = $newPassword;

                // Guardar los cambios en users.json
                file_put_contents($jsonFile, json_encode($usersData, JSON_PRETTY_PRINT));

                echo "<p>Contraseña para $username actualizada correctamente.</p>";
            } else {
                echo "<p>El usuario $username no fue encontrado.</p>";
            }
        }
    }
    ?>
</body>
</html>

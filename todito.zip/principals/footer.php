<!-- footer.php -->

<footer class="bg-dark text-white text-center py-3">
    <p>&copy; <?php echo date("Y"); ?> World Global. All rights reserved.</p>
</footer>

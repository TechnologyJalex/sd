<?php
// Aquí deberías obtener el ID de usuario actual desde la sesión o algún otro método de autenticación
$id_usuario = obtener_id_usuario_actual(); // Esta función debe obtener el ID del usuario actual

// Generar un enlace único basado en el ID del usuario
$enlace_referencia = 'http://tusitio.com/registrar.php?referido=' . $id_usuario;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Enlace de Referencia</title>
</head>
<body>
    <h1>¡Comparte este enlace para referir a otros usuarios!</h1>
    <p>Enlace de referencia: <a href="<?php echo $enlace_referencia; ?>"><?php echo $enlace_referencia; ?></a></p>
</body>
</html>
